import { PrismaClient } from "@prisma/client";
import argon2 from "argon2";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (email && password && password.length >= 12) {
    await prisma.adminUser.upsert({
      where: { email },
      update: {},
      create: { email, passwordHash: await argon2.hash(password, { type: argon2.argon2id }) }
    });
    console.log("Initial admin account created/verified.");
  } else {
    console.log("Admin seed skipped. Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ chars) in .env.");
  }

  const categories = [
    ["chandeliers", "Chandeliers", "झूमर"],
    ["led-lights", "LED Lights", "एलईडी लाइट्स"],
    ["ceiling-lights", "Ceiling Lights", "सीलिंग लाइट्स"],
    ["wall-lights", "Wall Lights", "दीवार की लाइट्स"],
    ["fans", "Fans", "पंखे"],
    ["decorative", "Decorative Lighting", "सजावटी लाइटिंग"]
  ] as const;

  for (const [slug, nameEn, nameHi] of categories) {
    await prisma.category.upsert({
      where: { slug }, update: {},
      create: { slug, nameEn, nameHi }
    });
  }

  const chandelier = await prisma.category.findUniqueOrThrow({ where: { slug: "chandeliers" } });
  const led = await prisma.category.findUniqueOrThrow({ where: { slug: "led-lights" } });
  const samples = [
    { slug: "crystal-grand-chandelier", nameEn: "Crystal Grand Chandelier", nameHi: "क्रिस्टल ग्रैंड झूमर", descriptionEn: "A statement chandelier for elegant living spaces.", descriptionHi: "शानदार लिविंग स्पेस के लिए आकर्षक झूमर।", sku: "RL-CH-001", price: 18500, categoryId: chandelier.id, featured: true },
    { slug: "modern-ring-pendant", nameEn: "Modern Ring Pendant", nameHi: "मॉडर्न रिंग पेंडेंट", descriptionEn: "Contemporary pendant lighting with a refined finish.", descriptionHi: "आधुनिक डिजाइन और सुंदर फिनिश वाली पेंडेंट लाइट।", sku: "RL-CH-002", price: 9200, categoryId: chandelier.id, featured: true },
    { slug: "premium-led-panel", nameEn: "Premium LED Panel", nameHi: "प्रीमियम एलईडी पैनल", descriptionEn: "Energy-efficient lighting for homes and offices.", descriptionHi: "घर और ऑफिस के लिए ऊर्जा-कुशल लाइटिंग।", sku: "RL-LED-001", price: 1250, categoryId: led, featured: true }
  ];
  for (const p of samples) {
    await prisma.product.upsert({ where: { slug: p.slug }, update: {}, create: p });
  }
}
main().finally(() => prisma.$disconnect());
