import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Royal Lighting | Premium Lighting Showroom in Rampur",
  description: "Explore premium chandeliers, LED lights and decorative lighting at Royal Lighting, Rampur, Uttar Pradesh. Request a quotation on WhatsApp."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
