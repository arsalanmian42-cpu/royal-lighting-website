"use client";

import { useMemo, useState } from "react";
import { ArrowRight, Search, ShoppingBag, MessageCircle, MapPin, Phone, Menu, X, Sparkles, ShieldCheck, Truck, Heart } from "lucide-react";

type Product = {
  id: string; slug: string; nameEn: string; nameHi: string;
  descriptionEn: string; descriptionHi: string; price: number | null;
  imageUrl: string | null; category: { nameEn: string; nameHi: string; slug: string };
};
const demo: Product[] = [
  { id:"demo-1", slug:"crystal-grand-chandelier", nameEn:"Crystal Grand Chandelier", nameHi:"क्रिस्टल ग्रैंड झूमर", descriptionEn:"A statement centrepiece for refined living spaces.", descriptionHi:"शानदार लिविंग स्पेस के लिए आकर्षक झूमर।", price:18500, imageUrl:"https://images.unsplash.com/photo-1543198126-a8ad8e47fb22?auto=format&fit=crop&w=900&q=85", category:{nameEn:"Chandeliers",nameHi:"झूमर",slug:"chandeliers"} },
  { id:"demo-2", slug:"modern-pendant-light", nameEn:"Modern Pendant Light", nameHi:"मॉडर्न पेंडेंट लाइट", descriptionEn:"Contemporary form with a warm ambient glow.", descriptionHi:"आधुनिक डिजाइन और गर्म रोशनी।", price:9200, imageUrl:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85", category:{nameEn:"Decorative",nameHi:"सजावटी लाइटिंग",slug:"decorative"} },
  { id:"demo-3", slug:"designer-wall-light", nameEn:"Designer Wall Light", nameHi:"डिजाइनर वॉल लाइट", descriptionEn:"Elegant accent lighting for bedrooms and hallways.", descriptionHi:"बेडरूम और गलियारे के लिए सुंदर लाइट।", price:2450, imageUrl:"https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=900&q=85", category:{nameEn:"Wall Lights",nameHi:"दीवार की लाइट्स",slug:"wall-lights"} },
  { id:"demo-4", slug:"premium-led-panel", nameEn:"Premium LED Panel", nameHi:"प्रीमियम एलईडी पैनल", descriptionEn:"Bright, efficient lighting for everyday spaces.", descriptionHi:"रोजमर्रा के स्थानों के लिए चमकदार और किफायती लाइट।", price:1250, imageUrl:"https://images.unsplash.com/photo-1558008258-3256797b43f3?auto=format&fit=crop&w=900&q=85", category:{nameEn:"LED Lights",nameHi:"एलईडी लाइट्स",slug:"led-lights"} }
];
const waNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "91XXXXXXXXXX";

export default function Home() {
  const [hi,setHi] = useState(false);
  const [query,setQuery] = useState("");
  const [category,setCategory] = useState("all");
  const [cart,setCart] = useState<string[]>([]);
  const [wishlist,setWishlist] = useState<string[]>([]);
  const [mobileOpen,setMobileOpen] = useState(false);
  const [products,setProducts] = useState<Product[]>(demo);
  const [formOpen,setFormOpen] = useState(false);
  const [sent,setSent] = useState(false);
  const [customer,setCustomer] = useState({name:"",phone:"",message:""});
  const t = (en:string, hindi:string) => hi ? hindi : en;

  useMemo(() => {
    fetch("/api/products").then(r=>r.ok?r.json():null).then(data=>{
      if (Array.isArray(data) && data.length) setProducts(data);
    }).catch(()=>{});
  }, []);

  const categories = [
    ["all","All","सभी"],["chandeliers","Chandeliers","झूमर"],["led-lights","LED Lights","एलईडी लाइट्स"],
    ["ceiling-lights","Ceiling Lights","सीलिंग लाइट्स"],["wall-lights","Wall Lights","दीवार की लाइट्स"],
    ["fans","Fans","पंखे"],["decorative","Decorative","सजावटी"]
  ];
  const filtered = products.filter(p =>
    (category==="all" || p.category.slug===category) &&
    `${p.nameEn} ${p.nameHi} ${p.category.nameEn}`.toLowerCase().includes(query.toLowerCase())
  );
  const quoteText = () => {
    const chosen = products.filter(p=>cart.includes(p.id));
    return `Hello Royal Lighting! I would like a quotation for:\n${chosen.map(p=>`• ${hi?p.nameHi:p.nameEn}`).join("\n")}\nPlease share price and availability.`;
  };
  const whatsapp = (message:string) => `https://wa.me/${waNumber.replace(/\D/g,"")}?text=${encodeURIComponent(message)}`;

  async function submitEnquiry(e:React.FormEvent) {
    e.preventDefault();
    const items = cart.map(id=>({productId:id,quantity:1})).filter(x=>!x.productId.startsWith("demo-"));
    if (!items.length) {
      window.open(whatsapp(`Hello Royal Lighting, I am ${customer.name}. ${customer.message}`),"_blank","noopener,noreferrer");
      return;
    }
    const response = await fetch("/api/enquiries",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      customerName:customer.name,phone:customer.phone,message:customer.message,items
    })});
    if(response.ok) setSent(true);
    else window.open(whatsapp(`Hello Royal Lighting, I am ${customer.name}. Phone: ${customer.phone}. ${quoteText()}`),"_blank","noopener,noreferrer");
  }

  return <main>
    <div className="dark-panel text-xs"><div className="container flex justify-between py-2 gap-3"><span>{t("Premium lighting for beautiful spaces","खूबसूरत घरों के लिए प्रीमियम लाइटिंग")}</span><span className="hidden sm:block">Rampur, Uttar Pradesh · India</span></div></div>
    <header className="bg-[#171717] text-white border-b border-white/10 sticky top-0 z-40">
      <div className="container flex items-center justify-between py-4 gap-4">
        <a href="#" className="leading-none"><span className="serif text-2xl tracking-[.12em] gold-text">ROYAL</span><span className="block text-[10px] tracking-[.42em] text-white/80 mt-1">LIGHTING</span></a>
        <nav className="hidden lg:flex items-center gap-7 text-sm text-white/80">
          <a href="#home" className="hover:text-[#d8b66f]">{t("Home","होम")}</a><a href="#products" className="hover:text-[#d8b66f]">{t("Products","प्रोडक्ट्स")}</a><a href="#about" className="hover:text-[#d8b66f]">{t("About","हमारे बारे में")}</a><a href="#contact" className="hover:text-[#d8b66f]">{t("Contact","संपर्क")}</a>
        </nav>
        <div className="flex items-center gap-2">
          <button onClick={()=>setHi(!hi)} className="border border-white/25 rounded-full px-3 py-2 text-xs">{hi?"EN":"हिंदी"}</button>
          <button onClick={()=>setFormOpen(true)} className="relative p-2" aria-label="Open quotation"><ShoppingBag size={20}/>{cart.length>0&&<span className="absolute -top-1 -right-1 bg-[#c6a15b] text-black text-[10px] rounded-full w-4 h-4 grid place-items-center">{cart.length}</span>}</button>
          <button className="lg:hidden p-2" onClick={()=>setMobileOpen(!mobileOpen)} aria-label="Toggle menu">{mobileOpen?<X/>:<Menu/>}</button>
        </div>
      </div>
      {mobileOpen&&<div className="lg:hidden px-5 pb-4 flex flex-col gap-3 text-sm"><a href="#home">{t("Home","होम")}</a><a href="#products">{t("Products","प्रोडक्ट्स")}</a><a href="#about">{t("About","हमारे बारे में")}</a><a href="#contact">{t("Contact","संपर्क")}</a></div>}
    </header>

    <section id="home" className="dark-panel relative overflow-hidden">
      <div className="absolute inset-0 opacity-35" style={{backgroundImage:"linear-gradient(90deg,#111 0%,#1118 55%,#1112),url(https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1800&q=90)",backgroundPosition:"center",backgroundSize:"cover"}}/>
      <div className="container relative py-24 md:py-36">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 text-[#d9b66d] text-xs tracking-[.25em] uppercase mb-6"><Sparkles size={15}/>{t("Illuminate your world","अपनी दुनिया रोशन करें")}</div>
          <h1 className="serif text-5xl md:text-7xl leading-[1.08] mb-6">{t("Lighting that makes a statement.","ऐसी रोशनी जो घर को खास बनाए।")}</h1>
          <p className="text-white/70 text-base md:text-lg max-w-xl leading-8 mb-9">{t("Discover elegant chandeliers, modern LED solutions and decorative lighting for every space.","हर जगह के लिए शानदार झूमर, आधुनिक एलईडी और सजावटी लाइटिंग की रेंज देखें।")}</p>
          <div className="flex flex-wrap gap-3"><a href="#products" className="gold-button rounded-sm px-6 py-3 text-sm font-semibold inline-flex items-center gap-2">{t("Explore collection","कलेक्शन देखें")} <ArrowRight size={16}/></a><a href="#contact" className="border border-white/40 text-white rounded-sm px-6 py-3 text-sm">{t("Visit showroom","शोरूम आएं")}</a></div>
        </div>
      </div>
    </section>

    <section className="bg-white border-b border-[#eee9df]"><div className="container grid grid-cols-1 sm:grid-cols-3 gap-6 py-6">
      {[["Curated collections","चुने हुए कलेक्शन",Sparkles],["Helpful product guidance","बेहतर प्रोडक्ट सलाह",ShieldCheck],["Enquire directly on WhatsApp","WhatsApp पर सीधे पूछें",MessageCircle]].map(([en,hiText,Icon]:any)=><div className="flex items-center gap-3" key={en}><div className="w-10 h-10 rounded-full bg-[#f4efe4] grid place-items-center text-[#a7833e]"><Icon size={19}/></div><span className="text-sm font-medium">{t(en,hiText)}</span></div>)}
    </div></section>

    <section id="products" className="container py-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 mb-9"><div><p className="text-[#a7833e] text-xs tracking-[.25em] uppercase mb-3">{t("Our collection","हमारा कलेक्शन")}</p><h2 className="serif text-4xl md:text-5xl">{t("Find your perfect light","अपनी पसंद की लाइट चुनें")}</h2></div><div className="relative w-full md:w-72"><Search className="absolute left-3 top-3 text-gray-400" size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t("Search products...","प्रोडक्ट खोजें...")} className="w-full border border-[#ded8cc] bg-white py-3 pl-10 pr-3 text-sm outline-none focus:border-[#b18d4b]"/></div></div>
      <div className="flex gap-2 overflow-x-auto pb-4 mb-6">{categories.map(([id,en,hiLabel])=><button key={id} onClick={()=>setCategory(id)} className={`whitespace-nowrap rounded-full border px-4 py-2 text-xs ${category===id?"bg-[#171717] text-white border-[#171717]":"bg-white border-[#ded8cc] hover:border-[#b18d4b]"}`}>{t(en,hiLabel)}</button>)}</div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">{filtered.map(p=><article className="product-card group" key={p.id}>
        <div className="relative aspect-[4/4.5] bg-[#f0ede7] overflow-hidden"><img src={p.imageUrl||"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800"} alt={hi?p.nameHi:p.nameEn} className="w-full h-full object-cover group-hover:scale-105 transition duration-500"/><button onClick={()=>setWishlist(old=>old.includes(p.id)?old.filter(x=>x!==p.id):[...old,p.id])} className="absolute right-3 top-3 bg-white/90 rounded-full p-2" aria-label="Toggle wishlist"><Heart size={17} fill={wishlist.includes(p.id)?"#b98f48":"none"} color={wishlist.includes(p.id)?"#b98f48":"#333"}/></button></div>
        <div className="p-4"><p className="text-[10px] uppercase tracking-[.18em] text-[#a7833e] mb-2">{hi?p.category.nameHi:p.category.nameEn}</p><h3 className="serif text-xl mb-2">{hi?p.nameHi:p.nameEn}</h3><p className="text-xs text-gray-500 leading-5 min-h-10">{hi?p.descriptionHi:p.descriptionEn}</p><div className="flex items-center justify-between mt-4 gap-2"><span className="font-semibold text-sm">{p.price?`₹${p.price.toLocaleString("en-IN")}`:t("Price on request","कीमत पूछें")}</span><button onClick={()=>setCart(old=>old.includes(p.id)?old:[...old,p.id])} className="text-xs border border-[#c6a15b] px-3 py-2 hover:bg-[#c6a15b]">{t("Add to quote","कोटेशन में जोड़ें")}</button></div><a target="_blank" rel="noreferrer" href={whatsapp(`Hello Royal Lighting, I am interested in ${hi?p.nameHi:p.nameEn}. Please share details.`)} className="mt-3 flex items-center gap-2 text-xs text-[#247c4c]"><MessageCircle size={15}/>{t("Ask on WhatsApp","WhatsApp पर पूछें")}</a></div>
      </article>)}</div>
      {filtered.length===0&&<p className="py-12 text-center text-gray-500">{t("No products found. Try another search.","कोई प्रोडक्ट नहीं मिला।")}</p>}
    </section>

    <section id="about" className="dark-panel"><div className="container grid md:grid-cols-2 gap-12 items-center py-20"><div><p className="text-[#d5b36c] text-xs tracking-[.25em] uppercase mb-3">{t("The Royal Lighting experience","रॉयल लाइटिंग का अनुभव")}</p><h2 className="serif text-4xl md:text-5xl mb-6">{t("The right light changes everything.","सही रोशनी हर जगह बदल देती है।")}</h2><p className="text-white/65 leading-8">{t("Explore lighting options for your home, office and special spaces. Our showroom team can help you find a style that fits your vision and budget.","अपने घर, ऑफिस और खास जगहों के लिए लाइटिंग विकल्प देखें। हमारा शोरूम आपकी पसंद और बजट के अनुसार सही विकल्प चुनने में मदद कर सकता है।")}</p></div><div className="grid grid-cols-2 gap-3"><img className="w-full h-56 object-cover" src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=700" alt="Elegant interior lighting"/><img className="w-full h-56 object-cover mt-10" src="https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=700" alt="Decorative lighting"/></div></div></section>

    <section id="contact" className="container py-20"><div className="text-center mb-10"><p className="text-[#a7833e] text-xs tracking-[.25em] uppercase mb-3">{t("Visit us","हमसे मिलें")}</p><h2 className="serif text-4xl">{t("Find Royal Lighting","रॉयल लाइटिंग आएं")}</h2><p className="text-gray-500 mt-3 text-sm">{t("Rampur, Uttar Pradesh, India","रामपुर, उत्तर प्रदेश, भारत")}</p></div><div className="grid md:grid-cols-3 gap-4">
      <div className="bg-white border border-[#e8e4dc] p-6"><MapPin className="text-[#b18d4b] mb-4"/><h3 className="font-semibold mb-2">{t("Showroom location","शोरूम का पता")}</h3><p className="text-sm text-gray-500">{process.env.NEXT_PUBLIC_SHOP_ADDRESS||"Add verified shop address, Rampur, Uttar Pradesh"}</p><a className="inline-block text-sm mt-4 underline" href={process.env.NEXT_PUBLIC_MAP_URL||"https://maps.google.com/?q=Rampur,Uttar+Pradesh"} target="_blank" rel="noreferrer">{t("Get directions","रास्ता देखें")}</a></div>
      <div className="bg-white border border-[#e8e4dc] p-6"><Phone className="text-[#b18d4b] mb-4"/><h3 className="font-semibold mb-2">{t("Call the showroom","शोरूम पर कॉल करें")}</h3><p className="text-sm text-gray-500">{process.env.NEXT_PUBLIC_SHOP_PHONE||"Add verified shop phone"}</p></div>
      <div className="bg-white border border-[#e8e4dc] p-6"><MessageCircle className="text-[#b18d4b] mb-4"/><h3 className="font-semibold mb-2">{t("WhatsApp enquiries","WhatsApp पूछताछ")}</h3><p className="text-sm text-gray-500 mb-4">{t("Ask about products, prices and availability.","प्रोडक्ट, कीमत और उपलब्धता पूछें।")}</p><a className="text-sm underline text-green-700" href={whatsapp("Hello Royal Lighting, I would like to know more about your products.")} target="_blank" rel="noreferrer">{t("Chat now","अभी चैट करें")}</a></div>
    </div></section>

    <footer className="dark-panel py-9"><div className="container flex flex-col md:flex-row items-center justify-between gap-4"><div><div className="serif text-xl gold-text tracking-widest">ROYAL LIGHTING</div><p className="text-white/45 text-xs mt-2">© {new Date().getFullYear()} Royal Lighting. {t("All rights reserved.","सर्वाधिकार सुरक्षित।")}</p></div><div className="flex gap-5 text-xs text-white/60"><a href="#home">{t("Home","होम")}</a><a href="#products">{t("Products","प्रोडक्ट्स")}</a><a href="#contact">{t("Contact","संपर्क")}</a><a href="/admin/login">{t("Admin","एडमिन")}</a></div></div></footer>

    <a href={whatsapp("Hello Royal Lighting! I have a product enquiry.")} target="_blank" rel="noreferrer" className="fixed bottom-5 right-5 z-40 rounded-full bg-[#20a45a] text-white p-4 shadow-xl" aria-label="WhatsApp"><MessageCircle size={24}/></a>

    {formOpen&&<div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4"><div className="bg-white w-full max-w-lg p-6 relative max-h-[90vh] overflow-auto"><button onClick={()=>setFormOpen(false)} className="absolute top-4 right-4"><X/></button><h2 className="serif text-3xl mb-2">{t("Request a quotation","कोटेशन का अनुरोध करें")}</h2><p className="text-sm text-gray-500 mb-5">{t(`${cart.length} product(s) selected` ,`${cart.length} प्रोडक्ट चुने गए`)}</p>{sent?<div className="bg-green-50 p-4 text-green-800 text-sm">{t("Enquiry submitted successfully. Our team will contact you.","आपकी पूछताछ भेज दी गई है। हमारी टीम संपर्क करेगी।")}</div>:<form onSubmit={submitEnquiry} className="space-y-3"><input required minLength={2} placeholder={t("Your name","आपका नाम")} value={customer.name} onChange={e=>setCustomer({...customer,name:e.target.value})} className="w-full border p-3 text-sm"/><input required placeholder={t("Phone number","फोन नंबर")} value={customer.phone} onChange={e=>setCustomer({...customer,phone:e.target.value})} className="w-full border p-3 text-sm"/><textarea placeholder={t("Message (optional)","संदेश (वैकल्पिक)")} value={customer.message} onChange={e=>setCustomer({...customer,message:e.target.value})} className="w-full border p-3 text-sm min-h-24"/><button className="gold-button w-full py-3 font-semibold">{t("Submit enquiry","पूछताछ भेजें")}</button><p className="text-[11px] text-gray-400">{t("If demo products are shown, your request will be prepared in WhatsApp until the database is connected.","डेमो प्रोडक्ट के लिए अनुरोध WhatsApp में तैयार होगा।")}</p></form>}</div></div>}
  </main>;
}
