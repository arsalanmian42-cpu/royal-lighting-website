import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { enquirySchema } from "@/lib/validation";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const parsed = enquirySchema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Please check your details and selected products." }, { status: 400 });

    const data = parsed.data;
    const productIds = [...new Set(data.items.map(i => i.productId))];
    const products = await db.product.findMany({ where: { id: { in: productIds }, available: true }, select: { id: true } });
    if (products.length !== productIds.length) return NextResponse.json({ error: "One or more selected products are unavailable." }, { status: 400 });

    const enquiry = await db.enquiry.create({
      data: {
        customerName: data.customerName,
        phone: data.phone,
        email: data.email || null,
        message: data.message || null,
        items: { create: data.items.map(i => ({ productId: i.productId, quantity: i.quantity })) }
      },
      select: { id: true, createdAt: true }
    });
    return NextResponse.json({ ok: true, reference: enquiry.id, createdAt: enquiry.createdAt }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Unable to submit enquiry right now." }, { status: 500 });
  }
}
