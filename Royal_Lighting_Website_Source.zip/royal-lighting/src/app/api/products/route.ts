import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const products = await db.product.findMany({
      where: { available: true },
      include: { category: { select: { nameEn: true, nameHi: true, slug: true } } },
      orderBy: [{ featured: "desc" }, { createdAt: "desc" }],
      take: 100
    });
    return NextResponse.json(products, { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } });
  } catch {
    return NextResponse.json({ error: "Product service unavailable" }, { status: 503 });
  }
}
