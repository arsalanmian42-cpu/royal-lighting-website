import { NextRequest, NextResponse } from "next/server";
import argon2 from "argon2";
import { z } from "zod";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";

const schema = z.object({ email: z.string().email().max(120), password: z.string().min(1).max(200) });

export async function POST(request: NextRequest) {
  try {
    const parsed = schema.safeParse(await request.json());
    if (!parsed.success) return NextResponse.json({ error: "Invalid login details." }, { status: 400 });
    const admin = await db.adminUser.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
    if (!admin || !(await argon2.verify(admin.passwordHash, parsed.data.password))) {
      return NextResponse.json({ error: "Email or password is incorrect." }, { status: 401 });
    }
    await createSession(admin.id);
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Login service unavailable." }, { status: 500 });
  }
}
