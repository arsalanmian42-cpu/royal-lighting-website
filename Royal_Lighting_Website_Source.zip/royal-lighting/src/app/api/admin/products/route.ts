import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getAdminSession } from "@/lib/auth";

const productSchema = z.object({
  slug: z.string().regex(/^[a-z0-9-]+$/).max(100),
  nameEn: z.string().min(2).max(120),
  nameHi: z.string().min(2).max(120),
  descriptionEn: z.string().max(2000),
  descriptionHi: z.string().max(2000),
  sku: z.string().max(60).optional().nullable(),
  price: z.number().int().nonnegative().nullable().optional(),
  imageUrl: z.string().url().max(1000).nullable().optional(),
  categoryId: z.string().min(1),
  featured: z.boolean().optional(),
  available: z.boolean().optional()
});

export async function POST(request: NextRequest) {
  if (!(await getAdminSession())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = productSchema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid product data." }, { status: 400 });
  try {
    const product = await db.product.create({ data: parsed.data });
    return NextResponse.json(product, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create product. Check unique slug/SKU and category." }, { status: 400 });
  }
}
