import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAdminSession } from "@/lib/auth";

export async function GET() {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const enquiries = await db.enquiry.findMany({
    include: { items: { include: { product: { select: { nameEn: true, sku: true } } } } },
    orderBy: { createdAt: "desc" }, take: 200
  });
  return NextResponse.json(enquiries);
}
