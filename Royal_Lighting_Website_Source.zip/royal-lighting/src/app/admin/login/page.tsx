"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function AdminLogin() {
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [error,setError]=useState("");
  const [busy,setBusy]=useState(false);
  const router=useRouter();

  async function submit(e:React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const res=await fetch("/api/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});
    const data=await res.json();
    setBusy(false);
    if(res.ok) router.push("/admin"); else setError(data.error||"Login failed");
  }
  return <main className="min-h-screen bg-[#171717] grid place-items-center p-5">
    <form onSubmit={submit} className="bg-white w-full max-w-md p-8 shadow-2xl">
      <p className="serif text-2xl text-[#b18d4b] tracking-widest">ROYAL LIGHTING</p>
      <h1 className="text-2xl font-semibold mt-8 mb-2">Admin sign in</h1>
      <p className="text-sm text-gray-500 mb-6">Authorized showroom administrators only.</p>
      <label className="block text-sm mb-2">Email</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} className="border w-full p-3 mb-4"/>
      <label className="block text-sm mb-2">Password</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} className="border w-full p-3 mb-4"/>
      {error&&<p className="text-sm text-red-600 mb-3">{error}</p>}
      <button disabled={busy} className="gold-button w-full py-3 font-semibold">{busy?"Signing in...":"Sign in securely"}</button>
      <Link href="/" className="block text-center text-sm underline mt-5">Back to website</Link>
    </form>
  </main>;
}
