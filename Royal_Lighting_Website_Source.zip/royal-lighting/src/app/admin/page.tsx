"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

type Enquiry = { id:string; customerName:string; phone:string; message:string|null; status:string; createdAt:string; items:{product:{nameEn:string};quantity:number}[] };
export default function AdminDashboard() {
  const [items,setItems]=useState<Enquiry[]>([]);
  const [error,setError]=useState("");
  const router=useRouter();
  useEffect(()=>{fetch("/api/admin/enquiries").then(async r=>{if(r.status===401){router.replace("/admin/login");return;}if(!r.ok)throw new Error("Unable to load enquiries");setItems(await r.json());}).catch(()=>setError("Could not load enquiries."));},[router]);
  async function logout(){await fetch("/api/admin/logout",{method:"POST"});router.replace("/admin/login");}
  return <main className="min-h-screen bg-[#f7f5f0]">
    <header className="bg-[#171717] text-white px-6 py-5 flex justify-between items-center"><div><p className="serif text-xl text-[#c6a15b] tracking-widest">ROYAL LIGHTING</p><p className="text-xs text-white/60">Admin dashboard</p></div><button onClick={logout} className="border border-white/30 px-4 py-2 text-sm">Log out</button></header>
    <div className="max-w-6xl mx-auto p-6 md:p-10"><div className="flex justify-between items-center mb-7"><div><h1 className="serif text-4xl">Enquiries</h1><p className="text-sm text-gray-500 mt-2">Recent customer quotation requests</p></div><Link href="/" className="text-sm underline">View website</Link></div>
      <div className="bg-white border p-5 mb-6"><p className="text-xs text-gray-500">TOTAL ENQUIRIES</p><p className="text-3xl font-semibold mt-1">{items.length}</p></div>
      {error&&<p className="text-red-600">{error}</p>}
      <div className="space-y-3">{items.map(item=><article key={item.id} className="bg-white border p-5"><div className="flex flex-col md:flex-row md:justify-between gap-2"><div><h2 className="font-semibold">{item.customerName}</h2><p className="text-sm text-gray-500">{item.phone}</p></div><span className="text-xs bg-[#f4efe4] px-3 py-1 self-start">{item.status}</span></div><p className="text-sm mt-3">{item.items.map(x=>`${x.product.nameEn} × ${x.quantity}`).join(", ")}</p>{item.message&&<p className="text-sm text-gray-600 mt-2">{item.message}</p>}<p className="text-xs text-gray-400 mt-3">{new Date(item.createdAt).toLocaleString()}</p></article>)}</div>
      {!items.length&&!error&&<p className="text-gray-500 py-10">No enquiries yet.</p>}
    </div>
  </main>;
}
