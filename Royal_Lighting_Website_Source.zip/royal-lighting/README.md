# Royal Lighting — Full-stack website starter

A bilingual (English/Hindi) lighting showroom website for Royal Lighting, Rampur, Uttar Pradesh, India.

## Included
- Premium black/gold responsive storefront
- English/Hindi interface toggle
- Product catalogue with search and category filters
- Wishlist and quote cart
- Product-specific WhatsApp links
- Enquiry submission API backed by PostgreSQL
- Prisma data model and demo seed products
- Admin login using Argon2id password hashes and signed HttpOnly session cookies
- Admin enquiry dashboard
- Server-side validation and basic security headers

## Important status
This is a working development starter, not a deployed or independently security-audited production service. Before public launch, configure real business details, database, hosting, HTTPS, backups, rate limiting, monitoring and test all workflows. Product demo images and sample product details must be replaced with Royal Lighting's actual catalogue.

## Requirements
- Node.js 20+
- PostgreSQL 14+
- npm

## Setup
1. Copy `.env.example` to `.env`.
2. Set `DATABASE_URL` to your PostgreSQL database.
3. Set `SESSION_SECRET` to a cryptographically random value of at least 32 characters.
4. Set `ADMIN_EMAIL` and a unique `ADMIN_PASSWORD` of at least 12 characters.
5. Set the verified shop phone, WhatsApp number, address and map URL.
6. Install and prepare:

```bash
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

Open http://localhost:3000. Admin login is at `/admin/login`.

## Production
- Use a managed PostgreSQL database and managed image storage.
- Configure environment variables in your hosting provider's secret manager.
- Run `npx prisma migrate deploy` during deployment.
- Use HTTPS and production cookie settings.
- Add rate limiting at the edge or in a shared backend store. The starter does not include distributed rate limiting.
- Add CSRF protection appropriate to your deployment and review origin checks for state-changing endpoints.
- Configure automated database backups and restore testing.
- Add email/WhatsApp operational alerts only after securing credentials and obtaining required business platform approval.
- Run dependency, security and end-to-end tests before launch.

## Admin
The first admin is created by `prisma/seed.ts` only when `ADMIN_EMAIL` and `ADMIN_PASSWORD` are set. Do not commit `.env`. Do not share admin credentials in source code or chat.

## WhatsApp
Direct chat uses `NEXT_PUBLIC_WHATSAPP_NUMBER` in international digits (for India, usually `91` followed by the 10-digit mobile number). Replace the placeholder before testing. Direct click-to-chat opens WhatsApp; it does not send messages automatically. Automated notifications require WhatsApp Business Platform setup and backend webhook/token configuration.

## Known next steps
- Add distributed rate limiting and robust CSRF/origin protection.
- Add admin product/category editing UI and enquiry status update UI.
- Add managed image upload workflow.
- Add persistent language preference and full translations for admin.
- Add customer-facing enquiry reference lookup if required.
- Add privacy policy, terms and consent/retention controls.
- Add unit, integration and end-to-end tests.
